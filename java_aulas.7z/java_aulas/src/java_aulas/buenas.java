package java_aulas;
//metodo publico
//static pertence a classe(sem objeto)
//void não retorna valor parecido com return 0 so que o retorno é null
//main metodo principal //vetor []uma lista igual python
public class buenas {
	public static void main(String[] args){
		System.out.println("buenas ao java");//tem que terminar com ;}
	}
}