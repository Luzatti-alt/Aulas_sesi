package java_aulas;

public class Iden {
	public static void main(String[] args){
		String nome ="A blu blé";
		int idade = 69;
		String cidade ="is goto";
		
		System.out.println("nome: "+nome);
		System.out.println("idade: "+idade);
		System.out.println("cidade: "+cidade);
		
	}
}
